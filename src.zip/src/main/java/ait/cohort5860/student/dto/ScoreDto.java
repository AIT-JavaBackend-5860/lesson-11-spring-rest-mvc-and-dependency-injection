package ait.cohort5860.student.dto;

import lombok.Getter;

@Getter
public class ScoreDto {
    private String examName;
    private Integer score;
}
